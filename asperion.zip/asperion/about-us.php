<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Our Firm's Open-mindedness about Technology</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header role="banner">
    <nav role="navigation">
      <h1>Asperion</h1>
      <ul class="nav-ul">
        <li><form action="index.php"><button type="submit">Home</button></form></li>
        <li><form action="profile.php"><button type="submit">About Us</button></form></li>
        <li><form action="profile.php"><button type="submit">Profile</button></form></li>
      </ul>
    </nav>
  </header>


        
            <div>
                <h1>About Us</h1>
                <p>Our firm was founded in 2005 by three highly experienced entrepreneurs with a vision to provide top-quality services to clients from all over the world. The three founders have a combined experience of over 50 years in the industry and have successfully managed the firm for the past 16 years.</p>
                <div>
                    <div>
                        <h1>KIKO</h1>
                        <p>CFO</p>
                    </div>
                    <div>
                        
                        <h1>JMIKEYDJI</h1>
                        <p>COO</p>
                    </div>
                    <div>
                        
                        <h1>S</h1>
                        <p>CEO</p>
                    </div>
                </div>
                <p>We take pride in our ability to manage our firm efficiently and effectively, providing our clients with the best services possible. Our team of highly skilled professionals is dedicated to delivering results that exceed our clients' expectations.</p>
            </div>
        </section>
    <img src="./pics/founder1.jpg" alt="Founder 1">
    <img src="./pics/founder2.jpg" alt="Founder 2">
    <img src="./pics/founder3.jpg" alt="Founder 3">

    <footer>
        <div class="container">
            <p>&copy; 2023 Our Firm Name. All rights reserved.</p>
        </div>
    </footer>