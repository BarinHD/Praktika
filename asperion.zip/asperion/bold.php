<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Our Firm's Open-mindedness about Technology</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header role="banner">
    <nav role="navigation">
      <h1>Asperion</h1>
      <ul class="nav-ul">
        <li><form action="index.php"><button type="submit">Home</button></form></li>
        <li><form action="about-us.php"><button type="submit">About Us</button></form></li>
        <li><form action="profile.php"><button type="submit">Profile</button></form></li>
      </ul>
    </nav>
  </header>

 
    <main>
        <section class="hero">
            <div class="hero-content">
                <h1>The Boldness of Our Firm</h1>
                <p>At Our Firm, we take bold risks and make bold decisions. Our fearless approach to business sets us apart from our competitors and allows us to push the boundaries of what is possible. If you're looking for a partner who isn't afraid to take risks and think outside the box, look no further than Our Firm.</p>
            </div>
        </section>
        <section class="services">
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2023 Our Firm Name. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>