<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Our Firm's Open-mindedness about Technology</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header role="banner">
    <nav role="navigation">
      <h1>Asperion</h1>
      <ul class="nav-ul">
        <li><form action="index.php"><button type="submit">Home</button></form></li>
        <li><form action="about-us.php"><button type="submit">About Us</button></form></li>
        <li><form action="profile.php"><button type="submit">Profile</button></form></li>
      </ul>
    </nav>
  </header>

 
  <div>
        <h1>Our Company's Creativity and Openness to New Ideas</h1>
        
        <p>At our company, we believe that creativity is key to success in any business. We are always looking for new and innovative ideas to help us and our clients achieve their goals.</p>
        <p>We value diversity and encourage everyone to bring their unique perspectives to the table. Whether you're a new employee or a long-time team member, your ideas are always welcome and appreciated.</p>
        <p>Our team consists of experts in various fields, from design and marketing to software development and project management. We work collaboratively to come up with the best solutions for our clients' needs.</p>
        <p>If you have an idea or suggestion, we would love to hear it! Please feel free to reach out to us anytime.</p>
        <img src="./pics/creative-team.jpg" alt="Creative team brainstorming">
        <img src="./pics/team-collaboration.jpg" alt="Team collaborating on a project">

    </div>

    <footer>
        <div class="container">
            <p>&copy; 2023 Our Firm Name. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>