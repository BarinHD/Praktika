<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Asperion Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="header">
	<h2>Home Page</h2>
</div>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="style.css">
</head>
  <header role="banner">
    <nav role="navigation">
      <h1>Asperion</h1>
      <ul class="nav-ul">
        <li><form action="index.php"><button type="submit">Home</button></form></li>
        <li><form action="about-us.php"><button type="submit">About Us</button></form></li>
        <li><button onclick="location.href='#projectsAnchor'">Projects</li>
        <li><form action="profile.php"><button type="submit">Profile</button></form></li>
      </ul>
    </nav>
  </header>
  <main role="main">
    <section class="sec-intro" role="section">
      <img src="https://www.techweekeurope.co.uk/wp-content/uploads/2012/07/wifimountaindownload.jpg" alt="" />
      <h1>Be Innovative!</h1>
    </section>
    <section class="sec-boxes" role="section">
      <adrticle class="box card2">
        <h1>Open-minded</h1>
        <p>Every option should be explored and tried no matter how unpredictable, impossible, insane or ridiculous does it look or sound. Our organization is always looking for the next challenge!</p>
        <form action="open-minded.php"><button class="button" type="submit" role="button" value="MORE">More</button></form>
      </adrticle>
      <adrticle class="box card2">
        <h1>Creative</h1>
        <p>Brainstorming, idea generation, playing sessions, note taking. You think you used everything? We will challenge your mind and its abilities to the limits.</p>
        <form action="creative.php"><button class="button" type="submit" role="button" value="MORE">More</button></form>
      </adrticle>
      <adrticle class="box card2">
        <h1>Bold</h1>
        <p>Our methods and ideas are are not written or following any books, curriculums or rules. We consider ourselves rebels and we are proud of it.</p>
        <form action="bold.php"><button class="button" type="submit" role="button" value="MORE">More</button></form>
      </adrticle>
      <adrticle class="box card2">
        <h1>Smart</h1>
        <p>Every project with innovation as a goal requires smart approach. Identify real problem first and look for the smartest and simplest solution later.</p>
        <form action="smart.php"><button class="button" type="submit" role="button" value="MORE">More</button></form>
      </adrticle>
    </section>
    <section class="sec-events" role="section">
      <hr />
      <h1>Upcomming events</h1>
      <article>
        <h1>Tire Technology Expo</h1>
        <p>Tire Technology Expo has grown in strength and stature every year since it was started in Europe 15 years ago. Visitors and exhibitors to the conference and exhibition staged in February 2014 universally praised it as the 'world's leading tire design and tire manufacturing event', noting in particular the outstanding quality of the conference papers and speakers, and the comprehensive extent of machinery manufacturers and suppliers who exhibited at the event.</p>
        <a class="link" href="#">more...</a>
      </article>
      <article>
        <h1>Meteorology World Expo</h1>
        <p>Meteorological Technology World Expo is a truly international exhibition of the very latest climate, weather and hydro - meteorological forecasting, measurement and analysis technologies and service providers for a global community of key decision makers within the aviation industry, shipping companies, marine / port installations, airports, military operations, off-shore exploration companies, wind farm operators, met offices, agriculture operations and research institutes.</p>
        <a class="link" href="#">more...</a>
      </article>
      <article>
        <h1>Wearable Tech Expo</h1>
        <p>See live demos, listen to case studies, speak with Wearable Tech Experts The first Wearable Tech Expo in Tokyo 2014. Key players from Japan, America and Europe announced their new products and attracted attention from all over the world. The next Wearable Tech Expo in Tokyo will be doubling in size and include Robotics and IoT. The main players in the wearable industry, human factor engineers, brain scientists, media providers and creators will discuss the future of wearable technology! </p>
        <a class="link" href="#">more...</a>
      </article>
      <article>
        <h1>Space Tech Expo</h1>
        <p>Space Tech Expo is the West Coast's premier B2B space event for spacecraft, satellite, launch vehicle and space-related technologies. Taking place in Long Beach, the Space Tech Expo exhibition and conference brings together global decision-makers involved in the design, build and testing of spacecraft, satellite, launch vehicle and space-related technologies. Leading the West Coast space and satellite industry, Space Tech Expo is where end-users connect with solution providers.</p>
        <a class="link" href="#">more...</a>
      </article>
    </section>
    <section class="sec-projects" role="section">
      <hr />
      <h1 id="projectsAnchor">Projects</h1>
      <article>
        <h1>Neural network for Google</h1>
        <p>People from Google approached us this January with offer to create new neural network for whole Google's ecosystem. This idea was very interesting and looked almost impossible at first glance. However, our engineers proved their expertise and built amazing autonomous platform. <a class="link" href="#">more...</a></p>
      </article>
      <article>
        <h1>Faster operating system for Apple</h1>
        <p>For a years, since founding days of a company, Apple always worked with its own operating system. In October, this was about to change. Our company got chance to rewrite the history by creating brand new OS for Apple. It was very difficult and all our employees worked hard every day. <a class="link" href="#">more...</a></p>
      </article>
      <article>
        <h1>Manufacturing technology for Intel</h1>
        <p>Intel has been manufacturing company for many years. They always used the latest technologies to achieve the best results with lowest costs. However, this was not enough. Intel decided to offer us something that could disrupt whole technology sector. <a class="link" href="#">more...</a></p>
      </article>
    </section>
    <section class="sec-standards" role="section">
      <hr />
      <h1>Our Standards</h1>
      <article>
        <h1>Excellence</h1>
        <p>Our goal is to give our customers the best solutions in highest aquality. Our employees strive for excellence and work hard to achieve it. Everything must work and be reliable. Great design must be both, aesthetic and functional. Product or service that pass these conditions will be everlasting.</p>
      </article>
      <article>
        <h1>Uniqueness</h1>
        <p>Our mantra is to create new paths. We are not interested in copying others because we know, that if you want to succeed, you have to be different, unique. Our customers know that we create unique products and experience for them. This is the best way to differentiate us and our brand from the noise on market. Unique, different and proud.</p>
      </article>
    </section>
    <section class="sec-partners" role="section">
      <hr />
      <h1>Our Partners</h1>
      <div class="row">
        <div class="logo-container">
          <img src="https://i.imgur.com/oSriTuP.png" alt="Google logo" />
        </div>
        <div class="logo-container">
          <img src="https://i.imgur.com/kRgvevC.png" alt="Apple logo" />
        </div>
        <div class="logo-container">
          <img src="https://i.imgur.com/ZZjeIP3.png" alt="Wii logo" />
        </div>
        <div class="logo-container">
          <img src="https://i.imgur.com/536rtCW.png" alt="Valve logo" />
        </div>
        <div class="logo-container">
          <img src="https://i.imgur.com/VTq1c9p.png" alt="Adithya Institute of Technology logo" />
        </div>
        <div class="logo-container">
          <img src="https://i.imgur.com/GdYoyxo.png" alt="Intel logo" />
        </div>
      </div>
    </section>
  </main>
</div>
<footer>
  <nav role="navigation">
    <ul class="nav-ul">
      <li><a href="#">Home</a></li>
      <li><a href="#">About Us</a></li>
      <li><a href="#">Technologies</a></li>
      <li><a href="#">Projects</a></li>
      <li><a href="#">Profile</a></li>
    </ul>
  </nav>
  <p class="copy">&copy; SavaKiko2023</p>
</footer>
<div class="line"></div>
<div class="content">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	<p>You are logged in as: <strong><?php echo $_SESSION['username']; ?></strong></p>
    	<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
    <?php endif ?>
</div>

</body>
</html>