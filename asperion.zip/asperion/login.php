<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Asperion Login</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Login</h2>
  </div>
	 
  <form method="post" action="login.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
	  <div class="input-container">
      <div class="input-content">
          <div class="input-dist">
              <div class="input-type">
                  <input placeholder="User" required type="text" name="username" class="input-is">  
                  <input placeholder="Password" required type="password" name="password" class="input-is">  
              </div>
          </div>
      	</div>
  		</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Login</button>
  	</div>
  	<p>
  		Not yet a member? <a href="register.php">Sign up</a>
  	</p>
  </form>
  <h1>Asperion</h1> 
</body>
</html>



