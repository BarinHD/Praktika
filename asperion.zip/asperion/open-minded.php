<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Our Firm's Open-mindedness about Technology</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header role="banner">
    <nav role="navigation">
      <h1>Asperion</h1>
      <ul class="nav-ul">
        <li><form action="index.php"><button type="submit">Home</button></form></li>
        <li><form action="about-us.php"><button type="submit">About Us</button></form></li>
        <li><form action="profile.php"><button type="submit">Profile</button></form></li>
      </ul>
    </nav>
  </header>

    <div>
        <h1>Our Firm's Open-mindedness about Technology</h1>
        <p>At our firm, we believe that technology is a vital tool for success in today's business world. We are always exploring new technologies and techniques to stay ahead of the curve.</p>
        <p>Our team consists of experts in various fields of technology, from web development and mobile apps to artificial intelligence and machine learning. We are always looking for new and innovative ways to improve our services and help our clients achieve their goals.</p>
        <p>Whether you're a small startup or a large corporation, we have the knowledge and expertise to help you succeed. Contact us today to learn more about our services.</p>
    </div>

    <footer>
        <div class="container">
            <p>&copy; 2023 Our Firm Name. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>