<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Asperion Profile</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<header role="banner">
    <nav role="navigation">
      <h1>Asperion</h1>
      <ul class="nav-ul">
        <li><form action="index.php"><button type="submit">Home</button></form></li>
        <li><form action="about-us.php"><button type="submit">About Us</button></form></li>
        <li><form action="profile.php"><button type="submit">Profile</button></form></li>
      </ul>
    </nav>
  </header>

<div class="content">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	<p>You are logged in as: <strong><?php echo $_SESSION['username']; ?></strong></p>
    	<p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
    <?php endif ?>
</div>

<footer>
        <div class="container">
            <p>&copy; 2023 Our Firm Name. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>
