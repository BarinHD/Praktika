<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Our Firm's Open-mindedness about Technology</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header role="banner">
    <nav role="navigation">
      <h1>Asperion</h1>
      <ul class="nav-ul">
        <li><form action="index.php"><button type="submit">Home</button></form></li>
        <li><form action="about-us.php"><button type="submit">About Us</button></form></li>
        <li><form action="profile.php"><button type="submit">Profile</button></form></li>
      </ul>
    </nav>
  </header>


  <section class="hero">
        <div class="hero-content">
            <h1>Our Smart Approach to Problem Solving</h1>
            <p>At Our Company, we take a smart and innovative approach to solving problems for our clients. We combine the latest technologies with our expertise to deliver effective solutions that meet your unique needs.</p>
        </div>
    </section>

        <div>
            <h2>Our Process</h2>
            <div class="process-steps">
                <div class="process-step">
                    <div class="process-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <h3>Step 1: Research and Analysis</h3>
                    <p>We start by researching and analyzing your problem to gain a deep understanding of your needs and objectives.</p>
                </div>
                <div class="process-step">
                    <div class="process-icon">
                        <i class="fas fa-cog"></i>
                    </div>
                    <h3>Step 2: Planning and Strategy</h3>
                    <p>Once we have a clear understanding of your problem, we develop a plan and strategy to address it effectively.</p>
                </div>
                <div class="process-step">
                    <div class="process-icon">
                        <i class="fas fa-code"></i>
                    </div>
                    <h3>Step 3: Implementation and Execution</h3>
                    <p>We then implement and execute our plan, using the latest technologies and our expertise to deliver effective solutions.</p>
                </div>
                <div class="process-step">
                    <div class="process-icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <h3>Step 4: Testing and Quality Assurance</h3>
                    <p>We thoroughly test and evaluate our solutions to ensure they meet your needs and are of the highest quality.</p>
                </div>
                <div class="process-step">
                    <div class="process-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <h3>Step 5: Monitoring and Optimization</h3>
                    <p>We continuously monitor and optimize our solutions to ensure they remain effective and meet your evolving needs.</p>
                </div>
            </div>
        </div>

        <footer>
        <div class="container">
            <p>&copy; 2023 Our Firm Name. All rights reserved.</p>
        </div>
    </footer>
